/**
 * 
 */
/**
 * 
 */
module QuickApp {
	 requires java.sql;
}